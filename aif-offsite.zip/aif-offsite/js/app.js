const PAGES = ['itinerary', 'rooms', 'cars'];

function showPage(id, btn) {
  PAGES.forEach(p => {
    document.getElementById('page-' + p).classList.remove('active');
  });
  document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));
  document.getElementById('page-' + id).classList.add('active');
  if (btn) btn.classList.add('active');
  history.replaceState(null, '', '#' + id);
}

function initFromHash() {
  const hash = location.hash.replace('#', '');
  const valid = PAGES.includes(hash) ? hash : 'itinerary';
  const btn = document.querySelector(`.nav-tab[data-page="${valid}"]`);
  showPage(valid, btn);
}

document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.nav-tab').forEach(btn => {
    btn.addEventListener('click', () => showPage(btn.dataset.page, btn));
  });
  initFromHash();
  window.addEventListener('hashchange', initFromHash);
});
